class QuickSort
  # Quick sort has average case time complexity O(nlogn), but worst
  # case O(n**2).

  # Not in-place. Uses O(n) memory.
  def self.sort1(array)
      return array if array.empty?

      start = array.first

      left = array.select { |el| start > el }
      middle = array.select { |el| start == el }
      right = array.select { |el| start < el }

      sort1(left) + middle + sort1(right)
    end

    def self.sort2!(array, start = 0, length = array.length, &prc)

    end

    def self.partition(array, start, length, &prc)
      prc ||= Proc.new { |el1, el2| el1 <=> el2 }

      start_idx = start
      start = array[start]

      ((start + 1)...(start + length)).each do |idx|
        if prc.call(start, array[idx]) > 0
          array[idx], array[start_idx + 1] = array[start_idx + 1], array[idx]
          start_idx += 1
        end
      end
      array[start], array[start_idx] = array[start_idx], array[start]




      start_idx
    end
end
